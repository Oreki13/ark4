﻿<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }


    public function index()
    {
        $data['title'] = "ARKADEMY BOOTCAMP";


        $this->load->view('template/header', $data);
        $this->load->view('ark/index');
        $this->load->view('template/footer');
    }

    public function table()
    {
        $data['title'] = "Query Table";


        $this->load->view('template/header', $data);
        $this->load->view('ark/7a');
        $this->load->view('template/footer');
    }

    public function statik()
    {
        $data['title'] = "Data Statik";


        $this->load->view('template/header', $data);
        $this->load->view('ark/7b');
        $this->load->view('template/footer');
    }
    public function dinamis()
    {
        $data['title'] = "Data Statik";
        $data['user'] = $this->db->get('nama')->row_array();


        $this->load->view('template/header', $data);
        $this->load->view('ark/7c', $data);
        $this->load->view('template/footer2');
    }

    public function tambah()
    {
        // $this->form_validation->set_rules('name', 'Name', 'required|trim');
        // $this->form_validation->set_rules('work', 'Name', 'required|trim');
        // $this->form_validation->set_rules('kategori', 'Name', 'required|trim');
        // if ($this->form_validation->run() == false) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data harus lengkap</div>');
        //     redirect('home/dinamis');
        // } else {
        $data = [
            'name' => htmlspecialchars($this->input->post('name')),
            'id_work' => $this->input->post('work'),
            'id_salary' => $this->input->post('kategori'),
        ];
        $this->db->insert('nama', $data);
        $this->session->set_flashdata('message', '<div class="alert alert-succes" role="alert">Data Berhasil Ditambahkan</div>');
        redirect('home/dinamis');
    }

    public function hapus($id)
    {

        $this->db->where('id', $id);
        $this->db->delete('nama');
        redirect('home/dinamis');
    }
}
