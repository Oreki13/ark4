<div class="row justify-content-center mt-5">
    <div class="col-md-4">
        <ul class="list-group list-group-flush">
            <li class="list-group-item text-center"><a class="text-decoration-none" href="<?= base_url('home/table') ?>">Jawaban Soal No 7A</a></li>
            <li class="list-group-item text-center"><a class="text-decoration-none" href="<?= base_url('home/statik') ?>">Jawaban Soal No 7B</a></li>
            <li class="list-group-item text-center"><a class="text-decoration-none" href="<?= base_url('home/dinamis') ?>">Jawaban Soal No 7C</a></li>

        </ul>
    </div>
</div>