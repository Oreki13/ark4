<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">


            <div class="row justify-content-end mt-5">
                <div class="col-md-1">
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#add">ADD</button>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md mt-3">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr class="text-center">
                                <th scope="col">Name</th>
                                <th scope="col">Work</th>
                                <th scope="col">Salary</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr>
                                <td>Rebecca</td>
                                <td>Frontend Dev</td>
                                <td>Rp.10.000.000</td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#hapus1"><i class="far fa-fw fa-trash-alt mx-2" href="#"></i></a>
                                    <a href="#" data-toggle="modal" data-target="#edit1"><i class="far fa-edit mx-2"></i></a></td>
                            </tr>
                            <tr>
                                <td>Vita</td>
                                <td>Backend Dev</td>
                                <td>Rp.12.000.000</td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#hapus2"><i class="far fa-fw fa-trash-alt mx-2" href="#"></i></a>
                                    <a href="#" data-toggle="modal" data-target="#edit2"><i class="far fa-edit mx-2"></i></a></td>
                            </tr>
                            <tr>
                                <td>Huda</td>
                                <td>Backend Dev</td>
                                <td>Rp.12.000.000</td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#hapus3"><i class="far fa-fw fa-trash-alt mx-2" href="#"></i></a>
                                    <a href="#" data-toggle="modal" data-target="#edit3"><i class="far fa-edit mx-2"></i></a></td>
                            </tr>
                            <tr>
                                <td>Kiky</td>
                                <td>Frontend Dev</td>
                                <td>Rp.10.000.000</td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#hapus4"><i class="far fa-fw fa-trash-alt mx-2" href="#"></i></a>
                                    <a href="#" data-toggle="modal" data-target="#edit4"><i class="far fa-edit mx-2"></i></a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row justify-content-center mt-2">
    <div class="col-md-2 text-center">
        <a href="<?= base_url('home') ?>" class="badge badge-primary">Kembali</a>
    </div>
</div>