﻿<!-- Melakukan Querry -->
<?php

$queryMenu =

    "SELECT nama.name as nama, work.name as work, kategori.name as kategori 
    FROM nama 
    JOIN work ON nama.id_work = work.id 
    JOIN kategori ON nama.id_salary = kategori.id
 
";
$menu = $this->db->query($queryMenu)->result_array();

?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Nama</th>
                    <th scope="col">Work</th>
                    <th scope="col">Salary</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menu as $q) :   ?>
                    <tr>
                        <td><?= $q['nama'] ?></td>
                        <td><?= $q['work'] ?></td>
                        <td><?= $q['kategori'] ?></td>

                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card">
            <div class="card-body">
                Saya menggunakan metode JOIN Table
                dengan Source code sebagai berikut:<br>
                <code>SELECT nama.name as nama, work.name as work, kategori.name as kategori<br>
                    FROM nama
                    JOIN work ON nama.id_work = work.id<br>
                    JOIN kategori ON nama.id_salary = kategori.id</code>
            </div>
        </div>
    </div>
</div>
<div class="row justify-content-center mt-2">
    <div class="col-md-2 text-center">
        <a href="<?= base_url('home') ?>" class="badge badge-primary">Kembali</a>
    </div>
</div>