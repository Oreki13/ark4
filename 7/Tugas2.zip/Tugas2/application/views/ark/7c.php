<?php

$queryMenu =

    "SELECT nama.id as id, nama.name as nama, work.name as work, kategori.name as kategori 
    FROM nama 
    JOIN work ON nama.id_work = work.id 
    JOIN kategori ON nama.id_salary = kategori.id
 
";
$menu = $this->db->query($queryMenu)->result_array();
?>

<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="row">
                <div class="col-md">
                    <?= $this->session->flashdata('message'); ?>
                </div>
            </div>
            <div class="row justify-content-end mt-5">
                <div class="col-md-1">
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#add">ADD</button>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md mt-3">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr class="text-center">
                                <th scope="col">Name</th>
                                <th scope="col">Work</th>
                                <th scope="col">Salary</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php foreach ($menu as $d) : ?>

                                <tr>
                                    <td><?= $d['nama'] ?></td>
                                    <td><?= $d['work'] ?></td>
                                    <td><?= $d['kategori'] ?></td>
                                    <td>
                                        <a href="<?= base_url(); ?>home/hapus/<?= $d['id'] ?>" onclick="return confirm('Yakin')"><i class=" far fa-fw fa-trash-alt mx-2" href="#"></i></a>
                                        <a href="<?= base_url(); ?>home/edit/<?= $d['id'] ?>" data-toggle="modal" data-target="#edit1"><i class="far fa-edit mx-2"></i></a></td>
                                </tr>
                            <?php endforeach ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row justify-content-center mt-2">
    <div class="col-md-2 text-center">
        <a href="<?= base_url('home') ?>" class="badge badge-primary">Kembali</a>
    </div>
</div>